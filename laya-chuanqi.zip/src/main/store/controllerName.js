/**
 * 控制器名称集合
 */
export default {
    GAME : 'gameController',
    SHOWS : 'showsController',
    EQ_SHOWS : 'equipmentShowController',
    TOOLS : 'toolsController',
    HEAD_MESSAGE : 'headMessageController',
    
    BAGPACK : 'bagpackController',
    BAG_LIST : 'bagListController',
    BAG_LIST_SHOW : 'bagListShowController',

    EQ_SKILL : 'equipmentSkillController',
    FOLLOWER : 'followerController',
    TRADE : 'tradeController',
    COPY : 'copyController'

}