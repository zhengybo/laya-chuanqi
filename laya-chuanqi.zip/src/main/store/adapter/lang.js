/**
 * 一些key值对应中文
 */
export default {
 equipmentAttrsMessage : {
     attback : '攻击',
     agile : '敏捷',
     power : '力量',
     intelligence : '智力'
 },
 roleAttrs : {
     blood : '血量',
     mana : '法力',
     level : '等级',
     attback : '攻击',
     
 }
}
