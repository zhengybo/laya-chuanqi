/**
 * 各种状态映射
 */
export default class Status {
    constructor(){

    }

    
}