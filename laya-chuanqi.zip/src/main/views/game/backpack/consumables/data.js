/**
 * 消耗品列表分类
 */


const action = [
    { id : 0, type : '', label : '使用' },
    { id : 1, type : 'helmet', label : '批量使用' },
    { id : 2, type : 'clothe', label : '寄售' },
]
export {
    action
} 