/**
 * 怪物类
 */
import Biology from './biology'

export default class Monster extends Biology{
    constructor(){

    }
}