/**
 * 战斗系统
 */

export default class Fight {
    constructor(){
        this.fightData= [
            [0,0,0,0],
            [100,100,100,200,300]
        ];
    }

    setFightObj(){

    }

    start(){

    }


}