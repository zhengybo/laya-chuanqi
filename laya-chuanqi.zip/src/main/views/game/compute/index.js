/**
 * 计算类
 * 用于计算各种伤害计算方式
 */

export default class Compute {
    constructor(){

    }

    
}
