export default [
  { name : "拉玛兰迪礼物", desc : "打孔用品" },
  { name : "未镶嵌", desc : "未镶嵌", },
  { name : "1级黄宝石", desc : "力量+10",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "2级黄宝石",   desc : "力量+20"，
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "3级黄宝石", desc : "力量+30"，
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "4级黄宝石", desc : "力量+50",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "5级黄宝石", desc : "力量+80",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "6级黄宝石", desc : "力量+110",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  {
    name : "7级黄宝石",
    desc : "力量+150",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  {
    name : "1级黄宝石",
    desc : "力量+10",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "2级黄宝石", desc : "力量+20",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "3级黄宝石", desc : "力量+30",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "4级黄宝石", desc : "力量+50",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  { name : "5级黄宝石",
    desc : "力量+80",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  {
    name : "6级黄宝石",
    desc : "力量+110",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
  {
    name : "7级黄宝石",
    desc : "力量+150",
    attrs : {
      power : 10,
      color : 'yellow'
    }
  },
].map((item, index) => Object.assign(item,{
  id : index,
  key :
})
