
export default [
  'fighter.json'
].map(v => `res/json/${v}`)
