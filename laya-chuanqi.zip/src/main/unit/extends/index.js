import { Functioned } from './../tool'
import Dom from './dom'

const extend = Functioned.extends;

export { 
    Dom, 
    extend
};