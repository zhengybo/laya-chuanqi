import Obj from './obj'
import Functioned from './functioned'
export {
  Obj, Functioned
}
